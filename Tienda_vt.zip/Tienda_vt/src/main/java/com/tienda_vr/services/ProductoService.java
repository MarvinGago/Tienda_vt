package com.tienda_vr.services;

import com.tienda_vr.domain.Producto;
import java.util.List;

public interface ProductoService {

    public List<Producto> getProductos(boolean activos);

    public Producto getProducto(Producto producto);

    public void save(Producto producto);

    public void delete(Producto producto);

    // Recupera la lista de productos basados en consultas ampliada
    public List<Producto> consulta1(double precioInf,
            double precioSup);

    // Recupera la lista de productos basados en consultas ampliada
    public List<Producto> consulta2(double precioInf,
            double precioSup);
    // Recupera la lista de productos basados en consultas ampliada

    public List<Producto> consulta3(double precioInf,
            double precioSup);
}
