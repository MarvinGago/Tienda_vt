package com.tienda_vr.services.impl;

import com.tienda_vr.dao.UsuarioDao;
import com.tienda_vr.domain.Rol;
import com.tienda_vr.domain.Usuario;
import com.tienda_vr.services.UsuarioDetailsService;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("userDetailsService")
public class UsuarioDetailsServiceImpl
        implements UsuarioDetailsService, UserDetailsService {

    @Autowired
    private UsuarioDao usuarioDao;
    @Autowired
    private HttpSession session;

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        // Se busca el usuario en la tabla usuario por medio del username
        Usuario usuario = usuarioDao.findByUsername(username);

//        Se valida si se encontro  el username pasado..
        if (usuario == null) {
            //El usurio no  se encontro
            throw new UsernameNotFoundException(username);
        }

//        Si se guarda aca entonces Si se encontro el usuario..
//        Guardamos la imagen del usuario en una variable de session.
        session.removeAttribute("imagenUsuario");
        session.setAttribute("imagenUsuario", usuario.getRutaImagen());
       
//       Se deben recuperar roles del usuario y crear Arraylist con Roles de seguridad
        var roles = new ArrayList<GrantedAuthority>();
        
//        Se revisan los roles de usuario y se convierten en roles de seguridad
         for (Rol r: usuario.getRoles()) {
             roles.add(new SimpleGrantedAuthority(r.getNombre()));
         }

//         Se retorna un usuario de seguridad con roles incluidos..
        return  new User (usuario.getUsername(),
                usuario.getPassword(),
                roles);
    }

}
