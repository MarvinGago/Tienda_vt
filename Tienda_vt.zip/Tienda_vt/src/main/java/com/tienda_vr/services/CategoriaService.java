package com.tienda_vr.services;

import com.tienda_vr.domain.Categoria;
import java.util.List;

public interface CategoriaService {

//    Se obtiene un listado de registros de la tabla de categoria
//    En un array lista de objetos categoria 
//    Todos o solo los activos
    public List<Categoria> getCategorias(boolean activos);

    public Categoria getCategoria(Categoria categoria);

    public void save(Categoria categoria);

    public void delete(Categoria categoria);

//    public getProductos(boolean b);

    
}
